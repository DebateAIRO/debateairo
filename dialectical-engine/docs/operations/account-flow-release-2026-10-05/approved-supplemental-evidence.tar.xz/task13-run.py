import sys,json,subprocess,datetime,time,os,signal,hashlib
from pathlib import Path
name,limit,*argv=sys.argv[1:]; limit=int(limit)
s=Path(__file__).parent; out=s/'task-13-logs';out.mkdir(exist_ok=True)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt={'name':name,'argv':argv,'cwd':os.getcwd(),'startedAt':now(),'timeoutSeconds':limit,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'diffSha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD'])).hexdigest()}
paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')
inputs={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in sorted(set(paths)) if name and Path(name).is_file()}
manifest=out/(name+'.source-sha256.json');manifest.write_text(json.dumps(inputs,indent=2)+'\n');receipt['sourceManifest']=str(manifest);receipt['sourceManifestSha256']=hashlib.sha256(manifest.read_bytes()).hexdigest()
start=time.monotonic()
with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
 p=subprocess.Popen(argv,stdout=stdout,stderr=stderr,start_new_session=True);receipt['pid']=p.pid
 try: receipt['exitCode']=p.wait(timeout=limit);receipt['timedOut']=False
 except subprocess.TimeoutExpired:
  receipt['timedOut']=True;os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  receipt['exitCode']=p.returncode;receipt['teardown']='owned process group terminated and reaped'
receipt.update(endedAt=now(),elapsedSeconds=round(time.monotonic()-start,3))
for suffix in ['stdout.log','stderr.log']:receipt[suffix+'Sha256']=hashlib.sha256((out/(name+'.'+suffix)).read_bytes()).hexdigest()
(out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));sys.exit(124 if receipt['timedOut'] else receipt['exitCode'])
